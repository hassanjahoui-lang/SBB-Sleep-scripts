local Framework = nil
local fatigue = 0.0          -- Livello di fatica (da 0 a 100)
local isSleeping = false     -- Stato di sonno
local cooldownNotif = false

-- Autodetect Framework (ESX / QBCore / Qbox)
Citizen.CreateThread(function()
    Citizen.Wait(100)
    if GetResourceState('es_extended') == 'started' then
        Framework = 'ESX'
        ESX = exports['es_extended']:getSharedObject()
    elseif GetResourceState('qbx_core') == 'started' then
        Framework = 'Qbox'
    elseif GetResourceState('qb-core') == 'started' then
        Framework = 'QB'
        QBCore = exports['qb-core']:GetCoreObject()
    end
end)

-- Loop di gestione e aumento della Stanchezza
Citizen.CreateThread(function()
    while true do
        local sleep = 5000
        local ped = PlayerPedId()

        if not isSleeping then
            -- Calcolo fatica in base alle azioni fisiche
            if IsPedSprinting(ped) or IsPedRunning(ped) then
                fatigue = fatigue + 2.0 -- Fatica rapida correndo
            elseif IsPedInAnyVehicle(ped, false) then
                fatigue = fatigue + 0.3 -- Fatica lenta guidando
            else
                fatigue = fatigue + 0.1 -- Aumento naturale del tempo
            end
        else
            sleep = 1000 -- Aggiornamento rapido mentre si dorme
            fatigue = fatigue - 3.0 -- Recupero energia
            if fatigue <= 0 then
                fatigue = 0
                SvegliaGiocatore()
            end
        end

        -- Limite fatica
        if fatigue > 100.0 then fatigue = 100.0 end
        if fatigue < 0.0 then fatigue = 0.0 end

        -- Trigger notifiche iOS basate sulla stanchezza
        if fatigue >= 75.0 and fatigue < 90.0 and not cooldownNotif then
            TriggerNotificaIOS("SALUTE", "Sei molto stanco", "I tuoi occhi iniziano a farsi pesanti. Dovresti andare a dormire.")
            cooldownNotif = true
            Citizen.SetTimeout(60000, function() cooldownNotif = false end) -- Cooldown di 1 minuto
        elseif fatigue >= 90.0 and not isSleeping then
            ColpoDiSonno() -- Avvia lo svenimento e l'animazione forzata
        end

        Citizen.Wait(sleep)
    end
end)

-- Effetto visivo "Colpo di Sonno" con Emote/Scenario di sonno forzato a terra
function ColpoDiSonno()
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) and not isSleeping then
        isSleeping = true -- Attiva lo stato di riposo
        
        TriggerNotificaIOS("EMERGENZA", "Sei svenuto!", "La fatica ha preso il sopravvento. Ti sei addormentato sul posto per lo sfinimento.")
        
        Citizen.CreateThread(function()
            -- Dissolvenza schermo in nero (il giocatore chiude gli occhi)
            DoScreenFadeOut(1500)
            Citizen.Wait(2000)
            
            -- Recupera le coordinate correnti sul terreno
            local coords = GetEntityCoords(ped)
            local heading = GetEntityHeading(ped)
            
            -- Forza il ped a sdraiarsi sulla schiena nella posizione corrente (Scenario nativo stabile)
            TaskStartScenarioAtPosition(ped, "WORLD_HUMAN_SUNBATHE_BACK", coords.x, coords.y, coords.z - 0.1, heading, 0, true, true)
            
            Citizen.Wait(3000)
            -- Dissolvenza schermo in entrata (il giocatore riapre gli occhi a terra)
            DoScreenFadeIn(1500)
        end)
    end
end

-- Comando manuale per dormire (/dormi)
RegisterCommand('dormi', function()
    local ped = PlayerPedId()
    if not isSleeping then
        if not IsPedInAnyVehicle(ped, false) then
            isSleeping = true
            TriggerNotificaIOS("SONNO", "Buonanotte", "Ti stai riposando. La tua energia si sta ricaricando...")
            
            -- Animazione Sonno alternativa (Lying down)
            RequestAnimDict("dead")
            while not HasAnimDictLoaded("dead") do Citizen.Wait(100) end
            TaskPlayAnim(ped, "dead", "dead_d", 8.0, 8.0, -1, 1, 0, false, false, false)
            
            DoScreenFadeOut(3000)
        else
            TriggerNotificaIOS("ERRORE", "Guida in corso", "Non puoi metterti a dormire mentre sei alla guida di un veicolo!")
        end
    else
        SvegliaGiocatore()
    end
end)

-- Risveglio del giocatore
function SvegliaGiocatore()
    if isSleeping then
        isSleeping = false
        local ped = PlayerPedId()
        ClearPedTasks(ped)
        DoScreenFadeIn(2000)
        TriggerNotificaIOS("SALUTE", "Sveglia", "Ti sei svegliato completamente riposato e pieno di energia.")
    end
end

-- Funzione di trigger Notifica iOS
function TriggerNotificaIOS(app, titolo, messaggio)
    SendNUIMessage({
        action = "notify",
        app = app,
        title = titolo,
        message = messaggio
    })
end