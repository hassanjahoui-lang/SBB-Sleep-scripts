fx_version 'cerulean'
game 'gta5'

author 'Assistente AI'
description 'Sistema di Stanchezza Standalone con Notifiche iOS'
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}